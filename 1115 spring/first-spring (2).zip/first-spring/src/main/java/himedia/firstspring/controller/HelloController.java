package himedia.firstspring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/* templates 패키지 내의 동적 페이지를 호출 하는 방법 */

@Controller // : 실제로는 Method
public class HelloController {
	
	/**
	 * 1. MVC
	 */
	// 이런걸 MVC(Model View Controller) 패턴이라 한다.
	// [Q1] {8080/first-mvc} -> first.html
	@GetMapping("first-mvc")
	public String first() {
		return "first";
	}

	/**
	 * 2. Template(thymeleaf)
	 * 		: view template을 통해 데이터 표현
	 */
	// 사용자가 url에 적는 hello 		ex) localhost:8080/hello
	@GetMapping("hello")	
	// client의 요청에 따라 @GetMapping, @PostMapping 어노테이션을 붙여줘야 함
	public String hello(Model model) {	// Model(interface) = 다형성으로 구현
		model.addAttribute("name", "홍길동");
		// server에서 client에게 보내주는 값 -> JSP로 보내줘야함 -> 복잡해서 thymeleaf 사용
		return "hello";
		// 요청에 응답할 hello.html
	}
	
	// [Q2] {8080/second-mvc?Fruit=apple} -> apple 출력
	@GetMapping("second-mvc")		// 사용자 요청
	public String second(@RequestParam("Fruit") String fruit, Model model) {
//		요청 : second-mvc?Fruit=apple --> fruit = apple 저장
		System.out.println("Fruit >> " + fruit);	// 값 확인 : apple
		System.out.println("model >> " + model);	// 		  : {} -> 받은게 없음
		model.addAttribute("Fruit", fruit);	// HTML file -> (Key, Value) 형태로 넘겨줌
		return "second";
	}
	
	// [Q3] {8080/third-mvc?Count=6} -> 6 출력
	@GetMapping("third-mvc")
	public String third(@RequestParam("Count") int count, Model model) {
		String s = "과일 개수 >> " + count;
		model.addAttribute("Count", s);
		return "third";									// Web으로 처리
	}
	
	/**
	 * 3-1. API 방식 : String으로 전송
	 */
	// [Q4] {8080/api-one?Fruit=banana} -> banana 출력
	@GetMapping("api-one")
	@ResponseBody
	public String apiOne(@RequestParam("Fruit") String fruit) {
		return "Query Parameter 'Fruit' : " + fruit;	// 문자열(String)로 처리
	}
	
//	===============================================
	// [Q4] {8080/api-two?Fruit=grape} -> grape 출력
	static class FruitInfo {
		private String fruit;

		public String getFruit() {
			return fruit;
		}

		public void setFruit(String fruit) {
			this.fruit = fruit;
		}
	}
	/**
	 * 3-2. API 방식 : json 형식으로 전송
	 *	(일반적으로) json 형식의 API 방식으로 데이터 전송
	 */
	@GetMapping("api-two")
	@ResponseBody
	public FruitInfo apiTwo(@RequestParam("Fruit") String fruit) {
		FruitInfo fruitInfo = new FruitInfo();
		fruitInfo.setFruit(fruit);
		return fruitInfo;
	}
	
	/*
	 * [과제]
	 * 1. Spring boot project 생성
	 *  - project : Gradle
	 * 	- group : himedia
	 * 	- artifact : alone
	 *  - package name : himedia.alone
	 *  - packaging : jar
	 *  - java : 11
	 *  - dependency : Spring Web, Thymeleaf
	 *  
	 * 2. 파일 추가
	 *  - static 폴더 : index.html 추가 --> index.html 페이지입니다.
	 *  - templates 폴더 : shop.html, stock.html, news.html
	 *  
	 *  	shop.html  -> get 방식으로 요청 : http://localhost:8080/shop?item=도시락
	 *  			   -> 응답 페이지 내 	  : (Thymeleaf)선택한 아이템은 도시락입니다.
	 *  
	 *  	stock.html -> get 방식으로 요청 : http://localhost:8080/stock?sise=220
	 *  			   -> 응답 페이지 내 	  : (Thymeleaf)요청된 시세는 220입니다.
	 *  
	 *  	news.html  -> get 방식으로 요청 : http://localhost:8080/news?economic=불경기
	 *  			   -> 응답 페이지 내 	  : (json) {"economic" : "불경기"}
	 */
	
}

